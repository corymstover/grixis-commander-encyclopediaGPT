GRIXIS COMMANDER ENCYCLOPEDIA — M8 EXACT-SOURCE RELEASE CANDIDATE
=============================================================
62/62 approved physical lists preserved byte-for-byte; 62 Archidekt imports.
180/180 original P1 cases accounted for, including 12 superseded cases.
62/62 commander-first attestations. All power brackets and 3 tags/deck present.
Six historically missing export metadata entries resolved from approval records.
Project-only banned/future cards are documented, not officially legal.
OWNER ACCEPTANCE IS SEPARATE: this artifact itself is not signed.
